const CONFIG = {
    introTitle: 'Babe à!',
    introDesc: `Trái đất vốn lạ thường
    Mà sao em cứ đi nhầm đường
    vào tim anh.`,
    btnIntro: 'hihi',
    title: '8/3 vui vẻ.',
    desc: 'Chúc em ngày càng xin đẹp,trẻ trung và luôn giữ nụ cười trên môi(Vì em đẹp nhất khi e cười :>) ',
    btnYes: 'Vẫn cứ là thích anh <33',
    btnNo: 'Không, Anh trai à :3',
    question:'Trên thế giới hơn 7 tỉ người mà sao em lại yêu anh <3',
    btnReply: 'Gửi cho anh <3',
    reply: 'Yêu thì yêu mà không yêu thì yêu <33333333',
    mess: 'Anh biết mà 🥰. Yêu em nhiều nhiều 😘😘',
    messDesc: 'Làm vợ anh nha!!.',
    btnAccept: 'Dạ,em đồng ý! <3',
    messLink: 'https://www.facebook.com/profile.php?id=100014982101534' //link mess của các bạn. VD: https://m.me/nam.nodemy
}